# Police-Studies-Map
Web Studio Project for Georgian College. Using Bootstrap and the Leaflet API.

##Group Members:
  Matthew Thoms, Katie Kramer, Chelsea Smith, Vatche Atikian

### How to start Building:
1. Pull the documents down from Github.
2. Put ALL the files into a folder.
3. Open CMD(PC) or Terminal(MAC).
4. Go to the folder where all the files are.
5. Type "npm start" to start the localhost server.
6. Open Browser and go to "http://localhost:3000" to open the web app.
